import sys
import numpy as np
from matplotlib import pyplot as plt
import matplotlib.animation as anim
import mpl_toolkits.mplot3d.axes3d as p3
import RungeKutta as rk

'''
trajectory = np.array([[[0, 0, 0]], [[2,2,2]]])
np.concatenate((trajectory[1], np.array([[1,2,3]])), axis=0)
trajectory = np.array([trajectory[0], np.concatenate((trajectory[1], np.array([[65,76,89]])), axis=0)])
array([[2, 2, 2],
       [1, 2, 3]])
'''

h = 0.001
points = 40000

c = 137
q = [1, -1]
m = [1837, 1]

time = []
trajectory = np.array([[], []])
velocity = np.array([])


def _retarded_index(body, current_index, t):
    global h
    zero = 1e-2
    current_time = time[current_index]
    _r = trajectory[body][current_index]

    guess_index = current_index - 1
    guess = time[guess_index]
    guess2_index = current_index - 2
    guess2 = time[guess2_index]

    while abs(guess2 - guess) >= zero:
        f1 = c * (t - guess) - np.linalg.norm(_r - trajectory[int(not body)][guess_index])
        f2 = c * (t - guess2) - np.linalg.norm(_r - trajectory[int(not body)][guess2_index])

        dnmntr = (f2 - f1)
        guess3 = guess2 - f2 * (guess2 - guess) / dnmntr

        guess = guess2
        guess_index = guess2_index
        guess2 = guess3
        guess2_index = int((guess3) * (1 / h))
        if guess2_index <= 0: break

    return guess2_index


def EBfield(body, index, position, t):
    global h
    global trajectory
    global velocity
    global time
    E = 0
    B = 0
    if index <= 2:
        R = position - trajectory[int(not body)][index]
        r = np.linalg.norm(R)
        R_unit = R / r
        E = q[int(not body)] / r ** 2
        E = E * R_unit
        B = np.cross(R_unit, E) / c

    else:
        ret_index = _retarded_index(body, index, t)

        R = position - trajectory[int(not body)][ret_index]
        r = np.linalg.norm(R)

        V = velocity[int(not body)][ret_index]
        V_h = velocity[int(not body)][ret_index - 1]
        V_dot = (V - V_h) / h
        v = np.linalg.norm(V)
        VR = np.dot(V, R)

        factor1 = 1 / (r - VR / c) ** 3
        factor2 = R - r * V / c
        factor3 = 1 - (v / c) ** 2
        factor4 = factor3 * factor2
        factor5 = V_dot / c ** 2
        factor6 = np.cross(factor2, factor5)
        factor7 = np.cross(R, factor6)
        factor8 = factor4 + factor7
        factor9 = factor1 * factor8

        E = q[int(not body)] * factor9

        R_unit = R / r
        B = np.cross(R_unit, E) / c

    return E, B


def LorentzForce(body, index, position, velocity, t):
    E, B = EBfield(body, index, position, t)
    V = velocity

    return q[body] * (E + np.cross(V, B))


def __velocity(position, velocity, t, **kwargs):
    return velocity


def __acceleration(position, velocity, t, **kwargs):
    body = 0
    index = 0
    if kwargs is not None:
        for key, value in kwargs.items():
            if key == "body":
                body = value
            elif key == "index":
                index = value
    else:
        sys.exit()

    beta = np.linalg.norm(velocity) / c
    factor1 = np.sqrt(1 - beta ** 2)
    factor2 = 1 + beta ** 2 / (1 - beta ** 2)
    factor3 = factor2 * m[body]
    factor4 = factor1 / factor3

    return factor4 * LorentzForce(body, index, position, velocity, t)


def _ode_solve(body, index):
    global h
    global trajectory
    global velocity
    global time

    last_position = trajectory[body][index]
    last_velocity = velocity[body][index]

    last_time = time[index]

    n_t, n_position, n_velocity = rk.get_single_point(last_position, last_velocity, last_time, __velocity,
                                                      __acceleration, h, 1, body=body, index=index)
    return n_position, n_velocity


def _init_trajectory():
    global trajectory
    global velocity
    global time

    shaped_zeroes = np.zeros(points * 3).reshape(points, 3)
    trajectory = np.array([shaped_zeroes, shaped_zeroes])
    velocity = np.array([shaped_zeroes, shaped_zeroes])

    radius = 0.01
    theta = np.pi / 4
    phi = np.pi / 4
    x_radius = radius * np.sin(theta) * np.cos(phi)
    y_radius = radius * np.sin(theta) * np.sin(phi)
    z_radius = radius * np.cos(phi)
    trajectory[0][0] = [0, 0, 0]
    trajectory[1][0] = [x_radius, y_radius, z_radius]
    velocity[0][0] = [0, 0, 0]
    velocity[1][0] = [0.001 * c, 0.001 * c, 0.001 * c]

    time = [0]


fig = plt.figure()
# ax = p3.Axes3D(fig)
ax = fig.gca(projection='3d')

ax.set_title("Trajectories",fontsize=18)
ax.set_xlabel("X Axis",fontsize=16)
ax.set_ylabel("Y Axis",fontsize=16)
ax.set_zlabel("Z Axis",fontsize=16)
# ax.set_xlim3d([0.0, 0.01])


def get_trajectory(index):
    global h
    global trajectory
    global velocity
    global time

    if index == 0:
        _init_trajectory()
    else:
        # For proton
        index -= 1
        n_position0, n_velocity0 = _ode_solve(0, index)

        print(n_position0)
        # tra_append0 = np.concatenate((trajectory[0], np.array([n_position0])), axis=0)
        # vel_append0 = np.concatenate((velocity[0], np.array([n_velocity0])), axis=0)

        trajectory[0][index + 1] = n_position0
        velocity[0][index + 1] = n_velocity0

        # For electron
        n_position1, n_velocity1 = _ode_solve(1, index)

        print(n_position1)
        # tra_append1 = np.concatenate((np.array([n_position1]), trajectory[1]), axis=0)
        # vel_append1 = np.concatenate((np.array([n_velocity1]), velocity[1]), axis=0)

        trajectory[1][index + 1] = n_position1
        velocity[1][index + 1] = n_velocity1

    time.append(time[-1] + h)
    index+=1
    ax.clear()
    ax.plot(trajectory[0][:index, 0], trajectory[0][:index, 1], trajectory[0][:index, 2], c='blue', marker='o', markersize=9)
    ax.plot(trajectory[1][:index, 0], trajectory[1][:index, 1], trajectory[1][:index, 2], c='red', marker='o', linestyle='none',
            markersize=3)
    ax.plot(np.array([trajectory[1][:index, 0][-1]]), np.array([trajectory[1][:index, 1][-1]]), np.array([trajectory[1][:index, 2][-1]]), c='green', marker='>',
            markersize=9)
    plt.savefig('twobody/figure{}'.format(index))

ani = anim.FuncAnimation(fig, get_trajectory, points, interval=100, blit=False)

# for i in range(0, 1000):
#     get_trajectory(i)
#
# ax.plot(trajectory[0][:, 0], trajectory[0][:, 1], trajectory[0][:, 2], c='blue')
# ax.plot(trajectory[1][:, 0], trajectory[1][:, 1], trajectory[1][:, 2], c='red')
#

plt.show()
